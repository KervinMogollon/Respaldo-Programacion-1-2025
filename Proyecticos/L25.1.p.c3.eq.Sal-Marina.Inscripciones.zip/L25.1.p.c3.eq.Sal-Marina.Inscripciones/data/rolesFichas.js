let rolesFichas = {
  agregar: 'agregar',
  modificar: 'modificar',
  eliminar: 'eliminar',
};

export default rolesFichas;