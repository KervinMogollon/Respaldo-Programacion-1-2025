let estudianteNuevo = {
  cedula: null,
  apellido: "",
  nombre: "",
};
export default estudianteNuevo;
