import vistas from "../data/vistas.js";
import rolesFichas from "../data/rolesFichas.js";

export default class Cl_vEliminarInscripcion {
    constructor() {
        this.controlador = null;
        this.vista = document.getElementById("eliminarInscripcionForm");
        this.vista.hidden = true;

      
    }
}