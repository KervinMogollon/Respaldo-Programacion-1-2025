let materiaNueva = {
  codigo: null,
  semestre: null,
  nombre: "",
};
export default materiaNueva;
