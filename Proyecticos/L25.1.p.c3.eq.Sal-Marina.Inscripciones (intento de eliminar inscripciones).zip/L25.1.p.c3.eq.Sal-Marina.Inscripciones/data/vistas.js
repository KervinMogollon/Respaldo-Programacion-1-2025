let vistas = {
  app: document.getElementById("appForm"),
  estudiante: document.getElementById("estudianteForm"),
  materia: document.getElementById("materiaForm"),
  inscripcion: document.getElementById("inscripcionForm"),
  estudiantes: document.getElementById("estudiantesForm"),
  materias: document.getElementById("materiasForm"),
  eliminarInscripcion: document.getElementById("eliminarInscripcionForm"),
};
export default vistas;