let dataInscritos = [
  { cedula: 102, materias: ["M01", "M03"] },
  { cedula: 104, materias: ["M02", "M03"] },
  { cedula: 105, materias: ["M04"] },
  { cedula: 107, materias: ["M05", "M01"] },
  { cedula: 108, materias: ["M04", "M02"] },
  { cedula: 109, materias: ["M02", "M03", "M04"] },
  { cedula: 110, materias: ["M01", "M03", "M04", "M05"] },
  { cedula: 111, materias: ["M02", "M03", "M05"] },
]

export default dataInscritos
