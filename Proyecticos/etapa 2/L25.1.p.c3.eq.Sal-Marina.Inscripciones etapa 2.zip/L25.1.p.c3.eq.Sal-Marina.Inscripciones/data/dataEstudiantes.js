let dataEstudiantes = [
    { cedula: 101, apellido: "Perez", nombre: "Juan" },
    { cedula: 102, apellido: "Gomez", nombre: "Pedro" },
    { cedula: 103, apellido: "Lopez", nombre: "Maria" },
    { cedula: 104, apellido: "Juárez", nombre: "Luis" },
    { cedula: 105, apellido: "Garrido", nombre: "Ana" },
    { cedula: 106, apellido: "Torres", nombre: "Carlos" },
    { cedula: 107, apellido: "Perez", nombre: "Luisa" },
    { cedula: 108, apellido: "Garcia", nombre: "Luisana" },
    { cedula: 109, apellido: "Linárez", nombre: "Anaís" },
    { cedula: 110, apellido: "Camacaro", nombre: "Carlota" },
    { cedula: 111, apellido: "Infante", nombre: "Luigi" }
]
export default dataEstudiantes