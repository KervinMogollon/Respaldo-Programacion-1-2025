let dataMaterias = [
  { codigo: "M01", semestre: 1, nombre: "Matemática I" },
  { codigo: "M02", semestre: 1, nombre: "Estadística I" },
  { codigo: "M03", semestre: 2, nombre: "Programación I" },
  { codigo: "M04", semestre: 3, nombre: "Técnicas de Estudios" },
  { codigo: "M05", semestre: 4, nombre: "Inglés" },
];
export default dataMaterias;
